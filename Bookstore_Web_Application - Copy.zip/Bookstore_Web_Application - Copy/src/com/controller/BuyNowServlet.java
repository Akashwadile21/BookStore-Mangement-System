package com.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.pojo.Books;

import com.model.BLManager;

/**
 * Servlet implementation class BuyNowServlet
 */
public class BuyNowServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		String bid=request.getParameter("bid");
		int id=Integer.parseInt(bid);
		BLManager bl=new BLManager();
		Books b=new Books();
		b=bl.searchSingleBook(id);
		if(b!=null) 
		{
			HttpSession sb=request.getSession();
			sb.setAttribute("book",b);
			response.sendRedirect("ShowSingleBook.jsp");
			
		}
		else
		{
			response.sendRedirect("");
		}
	}

}
