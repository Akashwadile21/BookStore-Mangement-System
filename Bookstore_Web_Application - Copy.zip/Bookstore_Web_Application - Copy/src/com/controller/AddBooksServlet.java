package com.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pojo.Books;

import com.model.BLManager;

/**
 * Servlet implementation class AddBooksServlet
 */
public class AddBooksServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String bid=request.getParameter("bookid");
		String bname=request.getParameter("bname");
		String pr=request.getParameter("bprice");
		double price=Double.parseDouble(pr);
		String auname=request.getParameter("auname");
		
		Books book=new Books();
		book.setBookid(bid);
		book.setBookname(bid);
		book.setBookname(bname);
		book.setPrice(price);
		book.setAuthorname(auname);
		
		BLManager bl=new BLManager();
		bl.saveBooks(book);
		response.sendRedirect("AddBooks.jsp");
	}

}
