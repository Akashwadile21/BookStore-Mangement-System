package com.controller;

import java.io.IOException;
import java.security.SecureRandom;
import java.util.Date;
import java.util.Random;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.pojo.Books;
import com.pojo.Order;
import com.pojo.Register;

import com.controller.Confirmservlet;
import com.model.BLManager;

@MultipartConfig(maxFileSize=16175455)
public class Confirmservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final Random RANDOM =new SecureRandom();
	public static final int PASSWORD_LENGTH=12;
	public static String generateRandomPassword()
	{
		String letter="ABCDEFGHIJKLMNOPQRSTUVWXYZ123456789";
		String pw="";
		for(int i=0;i<PASSWORD_LENGTH;i++)
		{
			int index=(int)(RANDOM.nextDouble()*letter.length()) ;
			pw+= letter.substring(index,index+1);
		
		}
		return pw;
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String ordId=Confirmservlet.generateRandomPassword();
		Date date=new Date();
		
		Register r=new Register();
		HttpSession s=request.getSession();
		r=(Register)s.getAttribute("em");
		
		Books b=new Books();
		HttpSession sb=request.getSession();
		b=(Books)sb.getAttribute("book");
		
		Order o=new Order();
	    o.setOrderid(ordId);
	    o.setOrderdate(date);
	    o.setRegister(r);
	    o.setBooks(b);
	    
	    BLManager bl=new BLManager();
	    bl.placeOrder(o);
	    response.sendRedirect("ThankYou.jsp");
	    
	    
		
	}
	}


