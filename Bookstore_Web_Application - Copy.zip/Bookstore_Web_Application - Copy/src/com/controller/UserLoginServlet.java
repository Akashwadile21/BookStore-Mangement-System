package com.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.model.BLManager;
import com.pojo.Register;


public class UserLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String e=request.getParameter("email");
		String p=request.getParameter("password");   
		BLManager bl=new BLManager();
		Register r=new Register();
		r=bl.searchByEmailPassword(e,p);
		if(r!=null)
		{
			HttpSession s=request.getSession();
			s.setAttribute("em",r);
			response.sendRedirect("BooksPortal.jsp");
		}
		else
		{
			response.sendRedirect("UserLogin.jsp");
		}
	}

}
