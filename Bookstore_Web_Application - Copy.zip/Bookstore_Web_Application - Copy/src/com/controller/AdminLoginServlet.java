package com.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.pojo.Admin;

import com.model.BLManager;

public class AdminLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String un=request.getParameter("uname");
		String p=request.getParameter("password");
		BLManager bl=new BLManager();
		Admin admin=new Admin();
		admin=bl.searchByEmailPasswordAdmin(un,p);
		if(admin!=null)
		{
			HttpSession s=request.getSession();
			s.setAttribute("admin",admin);
			response.sendRedirect("AddBooks.jsp");
		}
		else
		{
			response.sendRedirect("AdminLogin.jsp");
		}
	}

}
