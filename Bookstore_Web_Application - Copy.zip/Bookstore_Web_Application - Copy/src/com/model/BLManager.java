package com.model;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

import com.common.HibernateUtil;
import com.pojo.Admin;
import com.pojo.Books;
import com.pojo.Order;
import com.pojo.Register;

public class BLManager {

	public static final  SessionFactory s=HibernateUtil.sf;

	public void saveUserRegisterDate(Register r) {
		// TODO Auto-generated method stub
		Session s1=s.openSession();
		Transaction t=s1.beginTransaction();
		s1.save(r);
		t.commit();
		s1.close();
		
		
	}

	public Register searchByEmailPassword(String e, String p) {
		// TODO Auto-generated method stub
		Session s1=s.openSession();
		Criteria c=s1.createCriteria(Register.class);
		c.add(Restrictions.eq("email", e));
		c.add(Restrictions.eq("password", p));
		Register r=(Register)c.uniqueResult();
		return r;
	}

	public Admin searchByEmailPasswordAdmin(String un, String p) {
		// TODO Auto-generated method stub
		Session s1=s.openSession();
		Criteria c=s1.createCriteria(Admin.class);
		c.add(Restrictions.eq("username", un));
		c.add(Restrictions.eq("password", p));
		Admin admin=(Admin)c.uniqueResult();
		return admin;
	}

	public void saveBooks(Books book) {
		// TODO Auto-generated method stub
		Session s1=s.openSession();
		Transaction t=s1.beginTransaction();
		s1.save(book);
		t.commit();
		s1.close();
	}
	
	public List<Books>showBookList()
	{
		Session s1=s.openSession();
		Criteria c=s1.createCriteria(Books.class);
		List<Books> blist=c.list();
		return blist;
		
	}
	public Books searchSingleBook(int id) {
		// TODO Auto-generated method stub
		Session s1=s.openSession();
		Criteria c=s1.createCriteria(Books.class);
		c.add(Restrictions.eq("bid", id));
		Books b=(Books)c.uniqueResult();
		return b;
		
	}

	public void placeOrder(Order o) {
		// TODO Auto-generated method stub
		Session s1=s.openSession();
		Transaction t=s1.beginTransaction();
		s1.save(o);
		t.commit();
		s1.close();
	}
}
